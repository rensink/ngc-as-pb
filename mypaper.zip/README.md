# Nested Conditions as a Peircian Bicategory

This is an attempt to show if, or how, Nested Graph Conditions can be seen as a Peircian Bicategory

## Collaborators

- Andrea Corradini
- Arend Rensink

With thanks for input from Filippo Bonchi
